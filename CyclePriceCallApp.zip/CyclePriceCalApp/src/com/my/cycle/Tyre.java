package com.my.cycle;

import java.util.Date;

public class Tyre {
	
	private String tyreType;
	private Date orderDate;
	
	public Tyre(String tyreType , Date orderDate)
	{
		this.tyreType = tyreType;
		this.orderDate = orderDate;
		
	}
	
	public Double getPrice()
	{
		if(TyreType.TUBE_TYRE.name().equals(tyreType))
		{
			if(orderDate.compareTo(new Date(2019 , 12 , 31))< 0)
					{
				      return new Double(200);
					}
			else
			{
				return new Double(300);
			}
		}else if(TyreType.TUBE_TYRE.name().equals(tyreType))
		{
			if(orderDate.compareTo(new Date(2019 , 12 ,31)) < 0)
			{
				return new Double(300);
			}else {
				return new Double(400);
			}
		}
			return 0.00;
	}
	

	public static String getType(int value)
	{
		for(TyreType tyreType : TyreType.values())
		{
			if(tyreType.value == value)
			{
				return tyreType.name();
			}
		}
		return null;
	}
	
	public enum TyreType
	{
		TUBE_TYRE(1) , TUBELESS_TYRE(2);
		int value ;
		private TyreType(Integer value) {
			this.value = value;
		}
		public Integer getValue() {
			return value;
		}
	}
}
