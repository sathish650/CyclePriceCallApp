package com.my.cycle;

import java.util.Date;

public class Seat {
	
	private String seatType;
	private Date orderDate;
	
	public Seat(String seatType , Date orderDate)
	{
		this.seatType = seatType;
		this.orderDate = orderDate;
		
	}
	
	public Double getPrice()
	{
		if(SeatType.STEEL_SEAT.name().equals(seatType))
		{
			if(orderDate.compareTo(new Date(2019 , 12, 31))< 0)
					{
				      return new Double(200);
					}
			else
			{
				return new Double(300);
			}
		}else if(SeatType.STEEL_SEAT.name().equals(seatType))
		{
			if(orderDate.compareTo(new Date(2019 , 12 ,31)) < 0)
			{
				return new Double(200);
			}else {
				return new Double(300);
			}
		}
			return 0.00;
	}
	

	public static String getType(int value)
	{
		for(SeatType seatType : SeatType.values())
		{
			if(seatType.value == value)
			{
				return seatType.name();
			}
		}
		return null;
	}
	
	public enum SeatType
	{
		STEEL_SEAT(1) , IRON_SEAT(2);
		int value ;
		private SeatType(Integer value) {
			this.value = value;
		}
		public Integer getValue() {
			return value;
		}
	}
}
