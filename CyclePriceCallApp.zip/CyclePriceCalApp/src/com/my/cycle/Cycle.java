package com.my.cycle;

import java.util.Date;
import java.util.concurrent.Callable;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Cycle implements Callable<Cycle> {
	
	private Tyre tyre = null;
	private Gear gear = null;
	private Seat seat = null;
	private Double Price = null;
	private static Lock lock = new ReentrantLock(true);
	public Cycle(String tyreType, String gearType , String seatType , Date orderDate)
	{
		this.tyre = new Tyre(tyreType, orderDate);
		this.gear = new Gear(gearType , orderDate);
		this.seat = new Seat(seatType , orderDate);
	}
	
	private Double calculatePrice() {
		Double tyrePrice = this.tyre.getPrice();
		Double seatPrice = this.seat.getPrice();
		Double gearPrice = this.gear.getPrice();
		this.Price = tyrePrice + seatPrice + gearPrice;
		return Price;
		
	}
	
	public Tyre getTyre() {
		return tyre;
	}
  public void setTyre(Tyre tyre)
  {
	this.tyre = tyre;
  }
  
  public Gear getGear() {
	  return gear;
  }
  
  public void setGear(Gear gear) {
	  this.gear = gear;
  }
  
  public Seat getSeat() {
	  return seat;
  }
  public void setSeat(Seat seat) {
	  this.seat = seat;
  }
  
 
  public Cycle call() {
	  try {
		  lock.lock();
		  this.Price = this.calculatePrice();
	  }finally {
		  lock.unlock();
	  }
	  return this;
  }
  
  public Double getPrice() {
	  return Price;
  }
  public void setPrice(Double Price) {
	  this.Price = Price;
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
}
