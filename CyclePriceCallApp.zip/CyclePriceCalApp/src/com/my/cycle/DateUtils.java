package com.my.cycle;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class DateUtils {
	
	public static Date getdate(String DateStr)
	{
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try
		{
			return sdf.parse(DateStr);
		}
		catch(ParseException e)
		{
			e.printStackTrace();
		}
		return null;
	}

}
