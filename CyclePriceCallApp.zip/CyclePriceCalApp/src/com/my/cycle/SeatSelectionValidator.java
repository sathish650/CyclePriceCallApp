package com.my.cycle;

public class SeatSelectionValidator {
	
	public static Boolean isValidInput(Integer seatSelection)
	{
		boolean isValidInput = false;
		switch (seatSelection)
		{
		case 1 :
			isValidInput = true;
			break;
			
		case 2 :
			isValidInput = true;
			break;
			
		default :
			 isValidInput = false;
			 break;
		}
		return isValidInput;
	}

}
