package com.my.cycle;

import java.util.Date;

public class Gear {
	
	private String gearType;
	private Date orderDate;
	
	public Gear(String gearType , Date orderDate)
	{
		this.gearType = gearType;
		this.orderDate = orderDate;
		
	}
	
	public Double getPrice()
	{
		if(GearType.TWO_GEAR.name().equals(gearType))
		{
			if(orderDate.compareTo(new Date(2019 , 12 , 31))< 0)
					{
				      return new Double(100);
					}
			else
			{
				return new Double(200);
			}
		}else if(GearType.FOUR_GEAR.name().equals(gearType))
		{
			if(orderDate.compareTo(new Date(2019 , 12 ,31)) < 0)
			{
				return new Double(200);
			}else {
				return new Double(300);
			}
		}
			return 0.00;
	}
	

	public static String getType(int value)
	{
		for(GearType gearType : GearType.values())
		{
			if(gearType.value == value)
			{
				return gearType.name();
			}
		}
		return null;
	}
	
	public enum GearType
	{
		TWO_GEAR(1) , FOUR_GEAR(2);
		int value ;
		private GearType(Integer value) {
			this.value = value;
		}
		public Integer getValue() {
			return value;
		}
	}
}
