package com.my.cycle;

public class TyreTypeValidator {

		
		public static Boolean isValidInput(Integer tyreSelection)
		{
			boolean isValidInput = false;
			switch (tyreSelection)
			{
			case 1 :
				isValidInput = true;
				break;
				
			case 2 :
				isValidInput = true;
				break;
				
			default :
				 isValidInput = false;
				 break;
			}
			return isValidInput;
		}

	}


