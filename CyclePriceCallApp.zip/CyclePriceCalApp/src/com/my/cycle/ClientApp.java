package com.my.cycle;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.my.cycle.Gear.GearType;
import com.my.cycle.Seat.SeatType;
import com.my.cycle.Tyre.TyreType;

public class ClientApp {

	public static void main(String[] args)throws ParseException {
		System.out.println("Select Below Configuration to calculate price of Cycle");
		boolean isValidTyreSelection = Boolean.FALSE;
		Scanner scanner = new Scanner(System.in);
		String tyreSelection = null;
		String seatSelection = null;
		String gearSelection = null;
		
		while(!isValidTyreSelection) {
			System.out.println("select Tyre Type :");
			System.out.println(TyreType.TUBE_TYRE.getValue() + "." + TyreType.TUBE_TYRE.toString());
			System.out.println(TyreType.TUBELESS_TYRE.getValue() + "." + TyreType.TUBELESS_TYRE.toString());
			int tyreSelValue = scanner.nextInt();
			if(!TyreTypeValidator.isValidInput(tyreSelValue))
			{
				System.out.println("please select the option within the range of 1-2 from the above available options");
				
			}else {
				isValidTyreSelection = true;
				tyreSelection = Tyre.getType(tyreSelValue);
			}

		}
  boolean isValidSeatSelection = Boolean.FALSE;

	while(!isValidSeatSelection) {
		System.out.println("select Seat Type :");
		System.out.println(SeatType.STEEL_SEAT.getValue() + "." + SeatType.STEEL_SEAT.toString());
		System.out.println(SeatType.IRON_SEAT.getValue() + "." + SeatType.IRON_SEAT.toString());
		int seatSelValue = scanner.nextInt();
		if(!SeatSelectionValidator.isValidInput(seatSelValue))
		{
			System.out.println("please select the option within the range of 1-2 from the above available options");
			
		}else {
			isValidSeatSelection = true;
			seatSelection = Seat.getType(seatSelValue);
		}

	}

	  boolean isValidGearSelection = Boolean.FALSE;

		while(!isValidGearSelection) {
			System.out.println("select Gear Type :");
			System.out.println(GearType.TWO_GEAR.getValue() + "." + GearType.TWO_GEAR.toString());
			System.out.println(GearType.FOUR_GEAR.getValue() + "." + GearType.FOUR_GEAR.toString());
			int gearSelValue = scanner.nextInt();
			if(!GearSelectionValidator.isValidInput(gearSelValue))
			{
				System.out.println("please select the option within the range of 1-2 from the above available options");
				
			}else {
				isValidGearSelection = true;
				gearSelection = Gear.getType(gearSelValue);
			}
		}
		System.out.println("Enter order Date : (DD-MM-YYYY)");
		String orderDateStr = scanner.next();
		System.out.println("Enter no.of cycles:");
		Integer noOfCycles = scanner.nextInt();
		System.out.println("below the final configuration based on selection:");
		System.out.println("Tyre Selection :" + tyreSelection);
		System.out.println("Seat Selection :" + seatSelection);
		System.out.println("Gear Selection :" + gearSelection);
		System.out.println("Order Date :" + orderDateStr);
		System.out.println("No Of Cycles :" + noOfCycles );
		
		ExecutorService executorService = Executors.newFixedThreadPool(10);
		List<Cycle> cyclList = new ArrayList<>();
		Double totalCyclesPrice = new Double(0.00);
		System.out.println(DateUtils.getdate(orderDateStr));
		for(int i=1;i<=noOfCycles ; i++)
		{
			Cycle cycle = new Cycle(tyreSelection , seatSelection , gearSelection , DateUtils.getdate(orderDateStr));
			cyclList.add(cycle);
		}try
		{
			List<Future<Cycle>> resultList = executorService.invokeAll(cyclList);
			for(Future<Cycle> result : resultList)
          {
				Cycle cycle = result.get();
        	  System.out.println("Cycle Price Details - START");
			System.out.println("Cycle Price :" + cycle.getPrice());
        	System.out.println("Gear Price : " + cycle.getGear().getPrice());
        	System.out.println("Tyre Price :" + cycle.getTyre().getPrice());
        	System.out.println("Seat Price :" + cycle.getSeat().getPrice());
        	System.out.println("Cycle Price Details - END");
        	totalCyclesPrice = totalCyclesPrice + cycle.getPrice();
          }
		}
		catch(InterruptedException | ExecutionException e)
		{
		}
		System.out.println("Total Price of " +totalCyclesPrice +" is :" + totalCyclesPrice);	
		}
    }
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		